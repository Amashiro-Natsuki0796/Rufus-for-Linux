# Rufus for Linux

**把 Windows 平台上的 [Rufus](https://github.com/pbatard/rufus) 移植到 Linux。**

本项目不是重写，而是**真正的移植**：保留上游 Rufus 源码中平台无关的核心
子系统，只把 Win32 平台层替换为 POSIX/Linux 实现。

| | |
| --- | --- |
| 版本 | `1.2.1`（基于上游 Rufus `4.15`，检出提交 `875f221`） |
| 许可证 | `GPL-3.0-or-later` |
| 语言 / 构建 | C（C11）、GNU Make、纯 POSIX + GTK3 |
| 目标平台 | Debian 12/13、Ubuntu 22.04/24.04 及兼容发行版（x86_64 / aarch64） |

---

## 目录

- [特性](#特性)
- [权限模型](#权限模型)
- [安装](#安装)
- [构建](#构建)
- [使用](#使用)
  - [图形界面](#图形界面)
  - [命令行](#命令行)
  - [典型场景](#典型场景)
  - [自动决策规则](#自动决策规则)
  - [退出码](#退出码)
  - [故障排查](#故障排查)
- [移植了什么（代码复用）](#移植了什么代码复用)
- [项目结构](#项目结构)
- [与 Windows 版的差异](#与-windows-版的差异)
- [技术文档](#技术文档)
- [致谢与许可证](#致谢与许可证)

---

## 特性

| 功能 | 命令 | 说明 |
| --- | --- | --- |
| 设备枚举 | `rufus list` | sysfs 读取容量/总线/型号/序列号，自动识别系统盘 |
| 镜像分析 | `rufus info <iso>` | ISO9660 / UDF / Rock Ridge / Joliet / El Torito、Windows 盘识别 |
| 摘要校验 | `rufus checksum` | MD5 / SHA1 / SHA256 / SHA512 |
| 冲突进程检测 | `rufus ps` | 找出占用目标设备的进程，写入前自动拦截 |
| ISO 下载 | `rufus download` | 内置 53 条官方镜像目录，libcurl 下载 + 官方 SHA256 校验 |
| 原始写入 | `rufus write` | DD 模式，支持写后读回校验 |
| 创建启动盘 | `rufus create` | 分区 → 格式化 → PBR → 解包 → 引导器 → MBR 全流程 |
| 格式化 | `rufus format` | FAT32 / exFAT / NTFS / ext4 / UDF |
| 坏块检测 | `rufus badblocks` | 移植上游算法：512 KiB 逻辑块 + 5 组互补模式 |
| 分区表 | `rufus part` | 原生写入 MBR / GPT（含 GPT 头 CRC32 与备份表） |
| 引导记录 | `rufus mbr` | 13 种 MBR + 8 种 PBR，与 Windows 版写入完全相同的字节 |
| UEFI:NTFS | `create --uefi-ntfs` | 盘尾添加 FAT 分区，让 UEFI 固件能从 NTFS/exFAT 启动 |
| 图形界面 | `rufus-gtk` | GTK3，布局对齐 Windows 版 Rufus |

---

## 权限模型

**程序不需要用 `sudo` 启动。**

- **图形界面**：正常打开后立即弹出系统授权对话框（polkit / pkexec）。
  授权通过则以管理员权限运行；**取消授权则降级为只读模式** ——
  设备浏览、镜像分析、摘要计算、ISO 下载仍然可用，只是不能写入。
- **命令行**：`write` / `create` / `format` / `badblocks` / `mbr` / `part`
  这几个需要写设备的子命令会自动请求授权；其余子命令（`list`、`info`、
  `checksum`、`ps`、`download`、`uefi-ntfs`、`priv`）不需要任何权限。
- **`sudo` 方式仍然完全可用**，适合服务器、脚本与没有 polkit 的环境。

授权对话框显示的是本应用的图标与说明，而不是 polkit 默认文案 ——
这是靠随包安装的 `/usr/share/polkit-1/actions/io.github.rufus-linux.policy`
实现的（`exec.path` 关联程序、`allow_gui` 保留 `DISPLAY`/`XAUTHORITY`）。

用 `rufus priv` 可以查看当前权限状态与提权后端。
`rufus <命令> --help` 只显示用法，不会请求任何授权。

---

## 安装

### 方式一：Debian / Ubuntu 安装包（推荐）

```bash
sudo dpkg -i rufus-linux_1.2.1-1_amd64.deb
sudo apt-get -f install          # 自动补齐缺失依赖
```

卸载：

```bash
sudo apt-get remove rufus-linux
```

### 方式二：从源码构建后安装

```bash
make                             # 构建
sudo make install PREFIX=/usr    # 安装到 /usr
```

安装到默认前缀 `/usr/local`（不加 `PREFIX`）也是可以的，但此时
polkit 策略文件会装到 `/usr/local/share/polkit-1/actions/`，
部分发行版的 polkitd 不读取该路径 —— 建议显式指定 `PREFIX=/usr`。

卸载：

```bash
sudo make uninstall PREFIX=/usr
```

### 方式三：免安装直接运行

```bash
make
./build/rufus list
./build/rufus-gtk
```

构建树里运行时，程序会从 `data/` 目录读取资源（`iso-catalog.json`、
`uefi-ntfs.img`）。若资源不在预期位置，可用环境变量指定：

```bash
export RUFUS_UEFI_NTFS_IMG=/path/to/uefi-ntfs.img
```

> 注意：免安装方式下 polkit 策略文件没有安装，授权对话框会显示
> polkit 的默认文案（功能不受影响）。若需要正确的应用名与图标，
> 请安装 `.deb` 或执行 `make install`。

---

## 构建

### 1. 依赖

#### 编译依赖

| 依赖 | 必需性 | 用途 |
| --- | --- | --- |
| `gcc` / `make` / `pkg-config` | **必需** | 工具链 |
| `libgtk-3-dev` | 可选 | 图形界面；缺失时自动跳过 `rufus-gtk`，只构建命令行 |
| `libcurl4-openssl-dev` | 可选 | `rufus download` 的下载后端；缺失时自动回退到调用 `curl`/`wget` 命令行 |

Debian / Ubuntu：

```bash
sudo apt-get install -y build-essential make pkg-config
sudo apt-get install -y libgtk-3-dev libcurl4-openssl-dev
```

Fedora / RHEL：

```bash
sudo dnf install -y gcc make pkgconf-pkg-config gtk3-devel libcurl-devel
```

Arch：

```bash
sudo pacman -S --needed base-devel gtk3 curl
```

#### 运行时依赖

程序**自身不依赖** `parted`/`sgdisk` 来创建分区表 —— MBR 与 GPT 由
`src/core/rf_part.c` 直接按规范构造写入。下面这些是**功能依赖**，按用到的
功能安装即可。

| 依赖 | 提供的工具 | 缺了会怎样 |
| --- | --- | --- |
| `dosfstools` | `mkfs.vfat` | 无法格式化 FAT16/FAT32（**绝大多数启动盘都要用**） |
| `gdisk` | `sgdisk` | 仅用于人工验证分区表，不影响程序功能 |
| `pkexec` | `pkexec` | 无法免 sudo 授权，只能 `sudo` 启动 |
| `exfatprogs` | `mkfs.exfat` | 无法格式化 exFAT |
| `ntfs-3g` | `mkfs.ntfs` | 无法格式化 NTFS（Windows 安装盘必需） |
| `syslinux` + `syslinux-common` | `syslinux` | Linux ISO 的 BIOS 引导器装不上（不影响 UEFI 启动） |
| `udftools` | `mkudffs` | 无法格式化 UDF |
| `lxpolkit` / `polkit-1-auth-agent` / `mate-polkit` | 认证代理 | 图形界面无法弹授权对话框，会直接进只读模式 |

Debian / Ubuntu：

```bash
sudo apt-get install -y dosfstools gdisk pkexec \
                        exfatprogs ntfs-3g syslinux syslinux-common udftools
# 图形界面还需要一个 polkit 认证代理（多数桌面环境已自带）：
sudo apt-get install -y lxpolkit              # LXDE
sudo apt-get install -y polkit-1-auth-agent   # GNOME
```

### 2. 构建

```bash
make                 # 构建全部（默认 -O2）
make -j$(nproc)      # 并行构建
```

只构建命令行（无 GTK 环境，或只想用 CLI）：

```bash
make cli
```

只构建图形界面：

```bash
make gui
```

#### 构建产物

| 文件 | 说明 |
| --- | --- |
| `build/rufus` | 命令行程序（约 900 KB） |
| `build/rufus-gtk` | GTK3 图形界面（约 925 KB） |
| `build/librufuscore.a` | 核心静态库（含移植的第三方模块），供二次开发链接 |

#### 构建变量

所有变量都可以在命令行覆盖：

| 变量 | 默认值 | 说明 |
| --- | --- | --- |
| `PREFIX` | `/usr/local` | 安装前缀 |
| `BINDIR` | `$(PREFIX)/bin` | 可执行文件目录 |
| `DOCDIR` | `$(PREFIX)/share/doc/rufus-linux` | 文档目录 |
| `OPT` | `-O2` | 优化级别 |
| `CC` | `gcc` | 编译器 |
| `AR` | `ar` | 归档工具 |
| `PKG_CONFIG` | `pkg-config` | 依赖探测 |
| `CFLAGS` | 空 | 追加编译选项 |
| `LDFLAGS` | 空 | 追加链接选项 |

示例：

```bash
make OPT="-O3 -march=native" CC=clang -j$(nproc)
make PREFIX=/usr install
make CFLAGS="-fsanitize=address -g" cli     # 带 ASan 的调试构建
```

`libcurl` 与 `gtk+-3.0` 都是通过 `pkg-config` 在编译时探测的，探测结果
决定是否定义 `RF_HAVE_LIBCURL` 以及是否构建 GUI —— 不需要手动开关。

### 3. 安装布局

`sudo make install PREFIX=/usr` 安装以下内容：

| 路径 | 内容 |
| --- | --- |
| `/usr/bin/rufus` | 命令行程序 |
| `/usr/bin/rufus-gtk` | 图形界面 |
| `/usr/share/applications/rufus-linux.desktop` | 桌面菜单项 |
| `/usr/share/icons/hicolor/256x256/apps/rufus-linux.png` | 应用图标 |
| `/usr/share/polkit-1/actions/io.github.rufus-linux.policy` | polkit 授权策略（由 `.policy.in` 按 `BINDIR` 生成） |
| `/usr/share/rufus-linux/uefi-ntfs.img` | UEFI:NTFS 驱动镜像（1 MiB） |
| `/usr/share/rufus-linux/iso-catalog.json` | ISO 下载目录 |
| `/usr/share/man/man1/rufus.1`、`rufus-gtk.1` | 手册页 |
| `/usr/share/doc/rufus-linux/` | 本套技术文档 |

支持 `DESTDIR`，便于打包到临时目录：

```bash
make install DESTDIR=/tmp/stage PREFIX=/usr
```

### 4. 构建 .deb 安装包

```bash
sudo apt-get install -y debhelper devscripts lintian fakeroot
make deb                                # 等价于 dpkg-buildpackage -us -uc -b
```

产物在**上一级目录**：

```
../rufus-linux_1.2.1-1_amd64.deb
../rufus-linux-dbgsym_1.2.1-1_amd64.deb      # 调试符号包
```

质量检查：

```bash
lintian ../rufus-linux_1.2.1-1_amd64.deb     # 本版本无任何输出
```

### 5. 其他架构与交叉编译

代码只依赖 POSIX 与 GTK3，aarch64 上可直接构建：

```bash
# 本机构建
make -j$(nproc)

# 交叉编译（Debian/Ubuntu）
sudo apt-get install -y crossbuild-essential-arm64 libgtk-3-dev:arm64
dpkg-buildpackage -a arm64 -us -uc -b
```

### 6. 常见构建问题

| 现象 | 原因 | 解决 |
| --- | --- | --- |
| `[提示] 未找到 GTK3 开发包，跳过图形界面构建` | 缺 `libgtk-3-dev` | 安装它，或只用 `make cli` |
| `fatal error: cdio/iso9660.h: No such file` | 第三方头文件缺失 | 确认 `src/third_party/libcdio/cdio/` 存在 |
| `undefined reference to 'cdio_open'` | `cdio_shim.c` 未参与编译 | 确认 `src/third_party/libcdio/cdio_shim.c` 存在 |
| `undefined reference to 'curl_easy_init'` | 未链接 libcurl | 安装 `libcurl4-openssl-dev` 后 `make clean && make` |
| 改了 `Makefile` 但行为没变 | `make` 不知道 `.o` 依赖 Makefile | `make clean && make` |
| `_GNU_SOURCE redefined` 警告 | 构建系统与源文件同时定义 | 本项目已用 `#ifndef` 包裹，如出现在自定义补丁中请照做 |

### 7. 开发与调试

```bash
make clean && make -j$(nproc)     # 全量重建
./build/rufus help                # 冒烟测试
./build/rufus list                # 设备枚举（无需权限）

# 调试
gdb --args sudo ./build/rufus create --force img.iso /dev/loop0
sudo strace -f -e trace=openat,ioctl,pread64,pwrite64 ./build/rufus info /dev/sr0
```

**用回环设备做无风险测试**（推荐，本项目全部破坏性测试都这么做）：

```bash
dd if=/dev/zero of=/tmp/test.img bs=1M count=512
sudo losetup -P -f --show /tmp/test.img          # 假设输出 /dev/loop0
sudo chmod 666 /dev/loop0

./build/rufus part -y --force --scheme gpt /dev/loop0
./build/rufus format -y --force --fs fat32 --label TEST /dev/loop0p1
sudo sgdisk -v /dev/loop0                        # 用权威工具验证分区表

sudo losetup -d /dev/loop0
```

---

## 使用

> ⚠️ **写入 / 格式化 / 坏块检测 / 重建分区表会不可恢复地销毁目标设备上的
> 全部数据。** 程序会自动拒绝把系统盘作为目标（`--force` 也无法绕过），
> 但请务必先用 `rufus list` 亲自核对设备路径。

### 图形界面

#### 启动

```bash
rufus-gtk            # 不要加 sudo
```

启动后会立即弹出系统授权对话框：

- **输入密码确认** → 以管理员权限运行，全部功能可用；
- **点 Cancel** → 进入**只读模式**：顶部黄色横幅提示，"开始"按钮置灰，
  但设备浏览、镜像分析、摘要计算、ISO 下载都仍然可用。

如果桌面环境没有 polkit 认证代理，也可以继续 `sudo rufus-gtk`。

#### 界面说明

```
┌─────────────────────────────────────────────────────────────────────┐
│ 设备   [ /dev/sdb  14.9 GB  [USB]  SanDisk Cruzer ]            [刷新]│
│ 引导选择 [ ubuntu-24.04-desktop-amd64.iso ]        [📂] [下载 ISO]   │
├─────────────────────────────────────────────────────────────────────┤
│ 镜像信息                                                            │
│  /path/to/ubuntu-24.04-desktop-amd64.iso                            │
│  大小: 5.7 GB    类型: ISO9660+UDF                                  │
│  卷标: Ubuntu 24.04.1 LTS amd64                                     │
│  引导: BIOS + UEFI    BIOS: 是    UEFI: 是                          │
├─────────────────────────────────────────────────────────────────────┤
│ 分区类型 [ MBR (BIOS/UEFI-CSM 兼容) ▾ ]   目标系统 [ BIOS 或 UEFI ▾ ]│
│ 文件系统 [ FAT32 ▾ ]                       簇大小   [ 自动 ▾ ]       │
│ 卷标     [ UBUNTU_2404 ]                   坏块检测轮数 [ 0 ]        │
│ 选项     ☑ 可引导 U 盘（分区+格式化+解包）  ☐ 写后校验(DD)          │
│          ☐ UEFI:NTFS 分区                   ☑ 检测冲突进程          │
│ [ 开始 ]  ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓░░░░░░░░░░░░░░░░░░░░░░░░░░░░              │
│ 写入镜像 78.3%  45.2 MB/s  剩余 0:12                                 │
├─────────────────────────────────────────────────────────────────────┤
│ 日志     [12:34:56] INFO  创建 MBR 分区表: /dev/sdb …               │
└─────────────────────────────────────────────────────────────────────┘
```

| 控件 | 说明 |
| --- | --- |
| **设备** | 默认可移动设备；选中后显示容量与型号。系统盘/写保护盘会被拒绝 |
| **引导选择** | 选择 `.iso` / `.img` / `.wim`；选中后自动分析并推断默认值 |
| **下载 ISO** | 打开可搜索的镜像列表对话框，下载后自动 SHA256 校验 |
| **分区类型** | `MBR`：兼容 BIOS 与 UEFI-CSM；`GPT`：纯 UEFI 环境推荐 |
| **目标系统** | `BIOS 或 UEFI` / `仅 BIOS` / `仅 UEFI` |
| **文件系统** | `FAT32`（最通用，单文件 ≤ 4 GiB）、`exFAT`、`NTFS`（Windows 安装盘且 install.wim > 4 GiB 时必需）、`ext4`、`UDF` |
| **簇大小** | `自动` 按容量阶梯推荐 |
| **卷标** | FAT 最长 11 字符、NTFS/exFAT 最长 32 字符；非法字符自动替换为 `_` |
| **坏块检测轮数** | 0 = 跳过；1–4 = 写入前做 N 轮坏块扫描（耗时随容量线性增长） |
| **可引导 U 盘** | 勾选 = ISO 解包模式；不勾选 = DD 原始写入 |
| **写后校验(DD)** | 仅 DD 模式有效：写完后读回比对 SHA256 |
| **UEFI:NTFS 分区** | NTFS/exFAT 时在盘尾加一个小 FAT 分区，使 UEFI 固件仍能启动 |
| **检测冲突进程** | 默认勾选；写入前检查占用目标设备的进程 |

#### 操作流程

1. 插入 U 盘，点 **刷新**，在"设备"下拉框里选它 —— **核对容量和型号**；
2. 点文件夹图标选镜像（或点 **下载 ISO** 从网上下载）；
3. 程序自动分析镜像并填好分区类型/目标系统/文件系统/卷标；
   如需改动，按上表调整；
4. 点 **开始**，在确认对话框里核对一遍，然后等进度条走完；
5. 完成后**安全弹出**再拔盘。

#### 命令行参数

```bash
rufus-gtk [镜像文件] [选项]
  --device <路径>   预选目标设备（如 /dev/sdb）
  --all             列出包括非可移动设备在内的所有块设备
  -y, --yes         跳过确认对话框（脚本化使用）
  --auto-start      启动后自动开始写入（配合 --yes 使用）
  --no-polkit       不请求系统授权，直接以只读模式启动
```

无人值守示例：

```bash
rufus-gtk --all -y --auto-start --device /dev/sdb ~/ubuntu.iso
```

### 命令行

#### 通用形式

```bash
rufus <命令> [选项] [参数]
```

**全局选项**（可放在子命令之前或之后任意位置）：

| 选项 | 说明 |
| --- | --- |
| `-q, --quiet` | 静默模式，只输出错误 |
| `-v, --verbose` | 详细日志；`-vv` 输出跟踪级日志 |
| `-n, --no-progress` | 关闭进度条 |
| `-y, --yes` | 不询问确认 |
| `--no-polkit` | 不请求 polkit 授权（改用 sudo 方式） |
| `-h, --help` | 显示帮助 |

#### `list` —— 列出设备

```bash
rufus list           # 只列可移动设备
rufus list --all     # 列出全部块设备（含 loop / 光驱等）
```

```
设备         容量       总线    可移动 只读 已挂载 型号
--------------------------------------------------------------------------------
/dev/sdb     14.9 GB    USB     是     否   否     [USB] SanDisk Cruzer Blade
              序列号: 4C530001120523116142
/dev/sda     214.7 GB   SCSI    否     否   是     VMware,VMware Virtual S
```

不需要任何权限。**这是每次操作前的第一步** —— 确认设备路径。

#### `info` —— 分析镜像（只读，安全）

```bash
rufus info ubuntu-24.04-desktop-amd64.iso
```

```
镜像文件      : ubuntu-24.04-desktop-amd64.iso
文件大小      : 5.7 GB (6100000000 字节)
介质类型      : ISO9660
卷标          : Ubuntu 24.04.1 LTS amd64
引导能力      : BIOS + UEFI
  BIOS 引导   : 是
  UEFI 引导   : 是
  混合 MBR    : 是（可直接 DD 写入）
ISO9660       : 是
  块大小      : 2048 字节
  卷内数据    : 5.7 GB (2978526 块)
  Joliet 级别 : 0
  Rock Ridge  : 是
UDF           : 否
Linux 发行版盘: 是
推荐写入模式  : DD 原始写入
```

看最后一行决定怎么用：

- `推荐写入模式: DD 原始写入` → 用 `rufus create`（默认自动选 DD）或 `rufus write`
- `Windows 安装盘: 是` → 用 `rufus create`（ISO 解包模式）
- `引导能力: 不可引导` → 只是数据盘，用 `rufus format` 或 DD 写入

#### `checksum` —— 摘要计算与比对

| 选项 | 说明 |
| --- | --- |
| `-a, --algo <md5\|sha1\|sha256\|sha512>` | 摘要算法，默认 `sha256` |
| `-c, --check <十六进制摘要>` | 与实际值比对 |
| `-f, --file` | 强制按文件大小计算（默认对整盘/整个文件） |

```bash
rufus checksum ubuntu.iso                       # 默认 SHA256
rufus checksum -a sha512 ubuntu.iso
rufus checksum -c <官方公布的摘要> ubuntu.iso    # 退出码 2 表示不匹配
sudo rufus checksum /dev/sdb                    # 对设备整盘计算（需权限）
```

#### `ps` —— 冲突进程检测

```bash
rufus ps /dev/sdb          # 列出正在占用设备的进程
rufus ps --json /dev/sdb   # JSON 输出，便于脚本处理
```

```
检测到 3 个进程正在占用 /dev/loop0：

PID      进程               访问       方式             对象/命令行
------------------------------------------------------------------------------------------
49134    mount.ntfs           读写       打开块设备    /dev/loop0p1
49520    sleep                只读       打开挂载点文件 /mnt/nt/README.TXT
49574    sleep                cwd          工作目录在设备上 /mnt/nt
```

占用方式共 5 类：`打开块设备`、`打开挂载点文件`、`工作目录在设备上`、
`从设备运行程序`、`交换分区`。

退出码：`0` 无占用；`2` 有占用。`create`/`write`/`format` 会**自动**做这项检查。

#### `download` —— 在线下载 ISO

| 选项 | 说明 |
| --- | --- |
| `--list [过滤词]` | 列出目录条目；可按 id / 名称 / 分类过滤 |
| `--dir <目录>` | 保存目录（默认当前目录） |
| `--url <地址>` | 直接下载任意 URL（不使用目录） |
| `--update-catalog <URL>` | 下载新的目录文件到 `~/.config/rufus-linux/iso-catalog.json` |
| `--catalog <文件>` | 使用指定的目录文件 |
| `-N, --no-verify` | 跳过 SHA256 校验（不推荐） |

```bash
rufus download --list                    # 列出全部 53 条
rufus download --list ubuntu             # 按关键字过滤
rufus download ubuntu-2404-desktop-amd64 --dir ~/ISO
rufus download --url https://example.com/x.iso
```

下载流程：查表取官方 URL 与校验和信息 → 优先用目录内嵌 SHA256，
否则拉取官方校验和文件并解析 → libcurl 下载（`.part` 临时文件，
支持断点续传）→ **SHA256 不通过则报错并保留文件供人工检查**。

支持的官方校验和文件格式：coreutils 双列、coreutils `*` 标记、
BSD 风格 `SHA256 (file) = hash`、裸 hash、带路径前缀。

内置目录覆盖 Windows 评估版、Ubuntu、Debian、Fedora、Linux Mint、Arch、
Manjaro、openSUSE、Rocky、AlmaLinux、Kali、Pop!_OS、elementary OS、
Zorin OS、Raspberry Pi OS、FreeBSD、OpenBSD、GParted Live、SystemRescue、
Clonezilla、Memtest86+、Hiren's BootCD PE。

#### `write` —— 原始写入（DD 模式）

| 选项 | 说明 |
| --- | --- |
| `--verify` | 写完后读回并比对摘要 |
| `--hash <算法>` | 校验算法：`sha256`（默认）/ `sha1` / `md5` / `sha512` |
| `--force` | 允许把非可移动设备作为目标（系统盘仍被拒绝） |

```bash
rufus write ubuntu.iso /dev/sdb
rufus write --verify ubuntu.iso /dev/sdb
rufus write --verify --hash sha512 ubuntu.iso /dev/sdb
```

```
写入完成: 6100000000 字节，耗时 128.4 秒，平均 45.3 MB/s
镜像摘要: 8f2c...e91b
设备摘要: 8f2c...e91b
校验结果: 通过
```

**适用场景**：自带混合 MBR 的 Linux ISO、树莓派 `.img`、各类磁盘映像、
任何需要 1:1 复制的数据。

#### `create` —— 创建可引导 U 盘（推荐）

| 选项 | 取值 | 默认 | 说明 |
| --- | --- | --- | --- |
| `--mode` | `auto`/`dd`/`iso` | `auto` | 写入模式，规则见下 |
| `--target` | `both`/`bios`/`uefi` | `auto` | 引导目标 |
| `--scheme` | `mbr`/`gpt` | `mbr` | 分区方案 |
| `--fs` | `fat32`/`exfat`/`ntfs`/`ext4`/`udf` | 自动 | 目标文件系统 |
| `--label` | 字符串 | 镜像卷标 | 卷标 |
| `--cluster` | 字节数 | 自动 | 簇大小 |
| `--badblocks` | 1–4 | 0 | 写入前坏块检测轮数 |
| `--flash` | `1p`/`2p`/`slc`/`mlc`/`tlc` | `2p` | 坏块模式表 |
| `--verify` | — | 关 | DD 模式下写后校验 |
| `--no-syslinux` | — | 关 | 不安装 SYSLINUX |
| `--uefi-ntfs[=路径]` | — | 自动 | 强制启用 UEFI:NTFS 分区 |
| `--no-conflict-check` | — | 关 | 跳过冲突进程检测 |
| `--force` | — | 关 | 允许非可移动设备，并放行冲突进程 |

```bash
rufus create ubuntu-24.04.iso /dev/sdb                      # 全自动
rufus create --target both ubuntu.iso /dev/sdb              # BIOS + UEFI
rufus create --fs ntfs --label WIN11 win11.iso /dev/sdb     # Windows 安装盘
rufus create --scheme gpt --fs exfat img.iso /dev/sdb       # GPT + exFAT
rufus create --badblocks 1 ubuntu.iso /dev/sdb              # 先做 1 轮坏块检测
rufus create --mode dd disk.img /dev/sdb                    # 强制 DD
```

它执行的完整阶段：

```
1. 分析镜像（libcdio 读 PVD/UDF/El Torito）
2. 校验目标设备（系统盘 / 只读 / 可移动性）
3. 扫描冲突进程（占用则拒绝，仅"已挂载"会自动卸载处理）
4. 清除分区表（首尾各 1 MiB 清零）
5. 创建 MBR 或 GPT（原生写入，1 MiB 对齐）
6. 写入 UEFI:NTFS 驱动分区（NTFS/exFAT 且镜像可 UEFI 引导时）
7. 格式化（mkfs.vfat / exfat / ntfs / ext4 / udffs）
8. 写入分区引导记录 PBR（ms-sys）
9. 挂载 ISO（loop,ro）并复制内容到 U 盘
10. 安装引导器（SYSLINUX / 复制 isolinux）
11. 写入 MBR 引导代码（ms-sys）
```

> 提示：只要显式指定了 `--fs` 或 `--scheme`，自动模式就会选择
> ISO 解包路径（因为这两个选项只在解包模式下有意义）。

#### `format` —— 格式化

| 选项 | 说明 |
| --- | --- |
| `--fs <类型>` | **必填**：`fat32`/`exfat`/`ntfs`/`ext4`/`udf` |
| `--label <卷标>` | 卷标 |
| `--cluster <字节>` | 簇大小 |
| `--force` | 允许非可移动设备 |

```bash
rufus format --fs fat32 --label DATA /dev/sdb1
rufus format --fs exfat --label BACKUP /dev/sdb1
rufus format --fs ntfs --label WIN /dev/sdb1
rufus format --fs ext4 --label ROOT /dev/sdb1
rufus format --fs fat32 --cluster 32768 /dev/sdb1
```

只格式化**分区**（`/dev/sdb1`）。要重建分区表请先用 `rufus part`。

#### `badblocks` —— 坏块检测

| 选项 | 说明 |
| --- | --- |
| `-p, --passes <1..4>` | 写入模式轮数，默认 1 |
| `-F, --flash <1p\|2p\|slc\|mlc\|tlc>` | 闪存类型对应的模式表，默认 `2p` |

```bash
rufus badblocks /dev/sdb                    # 1 轮
rufus badblocks -p 2 /dev/sdb               # 2 轮
rufus badblocks -p 4 --flash tlc /dev/sdb   # 4 轮，TLC 模式表
```

```
坏块检测结果 (/dev/sdb, 双次写入(2 轮)):
  测试块数      : 61000
  坏块数量      : 0
  读错误        : 0
  写错误        : 0
  数据损坏错误  : 0
  结论          : 未发现坏块
```

> ⚠️ **破坏性操作**：会在整盘写入测试模式，原有数据全部丢失。
> 耗时与容量成正比（USB 2.0 上 16 GB 约需 20–40 分钟）。退出码 `4` 表示发现坏块。

#### `part` —— 重建分区表

| 选项 | 说明 |
| --- | --- |
| `-s, --scheme <mbr\|gpt>` | 分区方案，默认 `mbr` |
| `-f, --fs <类型>` | 决定 MBR 分区类型字节（FAT32 → `0x0C`，NTFS → `0x07`） |
| `-L, --label <卷标>` | 卷标 |
| `-X, --force` | 允许非可移动设备 |

```bash
rufus part --scheme mbr --fs fat32 --label USB /dev/sdb
rufus part --scheme gpt --label USB /dev/sdb
```

创建一个占据整盘的分区（起始 1 MiB）。GPT 由程序自己按 UEFI 规范构造，
包含头部 CRC32、主备表与保护性 MBR —— 用 `sgdisk -v` 验证会报告
`No problems found.`

#### `mbr` —— 引导记录

| 选项 | 说明 |
| --- | --- |
| `-t, --type <类型>` | MBR 引导代码类型，见下表 |
| `-p, --pbr <类型>` | 分区引导记录类型，见下表 |
| `-k, --keep-label` | 写 PBR 时保留原有卷标 |

**MBR 类型**（`-t`）：

| 取值 | 说明 |
| --- | --- |
| `rufus` / `rufus-msg` | Rufus MBR（可显示 UEFI:NTFS 提示） |
| `win7` | Windows 7 / Vista MBR（兼容性最好） |
| `2000` | Windows 2000 / XP MBR |
| `dos` / `95b` | 传统 DOS / Windows 95B MBR |
| `reactos` | ReactOS MBR |
| `grub2` / `grub4dos` | GRUB 2 / Grub4DOS MBR |
| `syslinux` / `syslinux-gpt` | SYSLINUX MBR / GPT 保护 MBR |
| `kolibrios` | KolibriOS MBR |
| `zero` | 清零 |
| `none` | 不写入（仅识别当前类型） |

**PBR 类型**（`-p`）：

| 取值 | 说明 |
| --- | --- |
| `fat32nt` | FAT32 + NTLDR/bootmgr（Windows 启动盘用） |
| `fat32pe` | FAT32 + PE |
| `fat32dos` | FAT32 + IO.SYS |
| `fat32ros` | FAT32 + ReactOS |
| `fat16` / `fat16ros` / `fat12` | FAT16 / FAT12 |
| `ntfs` | NTFS |

```bash
rufus mbr -t win7 /dev/sdb                     # 写 MBR 引导代码
rufus mbr -t none /dev/sdb                     # 只识别当前类型
rufus mbr -p fat32nt /dev/sdb1                 # 写 FAT32 PBR
rufus mbr -t syslinux -p ntfs --keep-label /dev/sdb
```

写入的引导代码与 Windows 版 Rufus **完全相同**（使用上游同一份
`mbr_*.h` / `br_*.h` 数据表）。

#### `uefi-ntfs` —— UEFI:NTFS 状态

```bash
rufus uefi-ntfs      # 显示驱动镜像位置与分区属性
```

#### `priv` —— 权限状态

```bash
rufus priv
```

```
权限状态
=========

当前用户      : uid=1000 (普通用户)
提权后端      : polkit (pkexec)
图形授权可用  : 是
由提权启动    : 否
```

### 典型场景

#### 制作 Ubuntu 安装盘

```bash
rufus list                                          # 1. 确认设备
rufus info ubuntu-24.04-desktop-amd64.iso           # 2. 看一眼镜像
rufus create ubuntu-24.04-desktop-amd64.iso /dev/sdb  # 3. 制作
```

#### 制作 Windows 11 安装盘（install.wim > 4 GiB）

```bash
rufus info win11.iso
rufus create --fs ntfs --label WIN11 win11.iso /dev/sdb
```

程序会自动在盘尾添加 UEFI:NTFS 分区，使 UEFI 固件仍能从 NTFS 启动。
产物布局（`sgdisk -p` 查看）：

```
Number  Start (sector)    End (sector)  Size       Code  Name
   1            2048         1044479   509.0 MiB   0700  WIN11
   2         1044480         1046527   1024.0 KiB  0700  UEFI:NTFS
```

#### 下载官方 ISO 再制作

```bash
rufus download --list debian
rufus download debian-13-netinst-amd64 --dir ~/ISO
rufus create ~/ISO/debian-13.7.0-amd64-netinst.iso /dev/sdb
```

#### 制作树莓派镜像卡

```bash
rufus write --verify raspios.img /dev/sdb
```

#### 校验下载的 ISO 是否完整

```bash
EXPECT=$(curl -sL https://releases.ubuntu.com/24.04/SHA256SUMS | grep desktop | cut -d' ' -f1)
rufus checksum -c "$EXPECT" ubuntu.iso
```

#### 把旧 U 盘当普通数据盘用

```bash
rufus part --scheme mbr --fs exfat --label DATA /dev/sdb
rufus format --fs exfat --label DATA /dev/sdb1
```

#### 检查 U 盘是否可靠

```bash
rufus badblocks -p 2 /dev/sdb
# 报告坏块 → 更换设备
```

#### 修复 Windows 启动盘的 PBR

```bash
rufus mbr -t win7 --pbr fat32nt /dev/sdb
```

#### 批量制作（脚本）

```bash
#!/bin/bash
set -e
ISO="$1"
for dev in /dev/sd{b,c,d}; do
    echo ">>> 制作 $dev"
    rufus -y create --force "$ISO" "$dev"
done
```

### 自动决策规则

#### 写入模式（`--mode auto`）

```
映像类型 == 磁盘映像(MBR/GPT) 或 原始数据   →  DD 原始写入
Windows 安装盘 且 镜像无混合 MBR            →  ISO 解包模式
其他（Linux ISO / 数据 ISO）                →  DD 原始写入
显式指定 --fs 或 --scheme                   →  ISO 解包模式
```

#### 目标文件系统（未指定 `--fs`）

```
Windows 安装盘:
    install.wim > 4 GiB  →  NTFS
    否则                  →  FAT32
其他镜像                  →  FAT32
```

#### MBR 引导代码（`create` 自动选择）

```
GPT 方案        →  SYSLINUX GPT 保护 MBR
Windows 安装盘  →  Rufus MBR
其他            →  Windows 7/Vista MBR
```

#### 是否需要 UEFI:NTFS 分区

```
镜像可 UEFI 引导  且  文件系统为 NTFS/exFAT  →  需要
显式 --uefi-ntfs                              →  强制需要
```

### 退出码

| 码 | 含义 |
| --- | --- |
| 0 | 成功 |
| 1 | 一般错误（参数、权限、设备不存在…） |
| 2 | 摘要校验不匹配；或 `rufus ps` 发现占用 |
| 3 | 写入后读回校验失败 |
| 4 | 坏块检测发现坏块 |

### 故障排查

| 现象 | 原因 | 解决 |
| --- | --- | --- |
| 启动后没弹授权对话框，直接进只读模式 | 桌面环境没装 polkit 认证代理 | 装 `lxpolkit` / `polkit-1-auth-agent` / `mate-polkit`，或改用 `sudo rufus-gtk` |
| 授权对话框显示英文 "Run a program as another user" | 策略文件未安装或路径不匹配 | 重新安装本包；确认 `/usr/share/polkit-1/actions/io.github.rufus-linux.policy` 存在 |
| 命令行报 `该操作需要管理员权限` | 未安装 pkexec | `sudo apt install pkexec`，或改用 `sudo rufus ...` |
| `拒绝操作: 该设备承载系统根/启动分区` | 目标选了系统盘 | 选对设备；此限制**不可绕过** |
| `拒绝操作: 设备不是可移动介质` | 目标是内置硬盘 | 确认无误后加 `--force` |
| `拒绝操作: 设备为只读` | U 盘写保护开关 / 只读属性 | 关掉写保护开关；`sudo hdparm -r0 /dev/sdb` |
| `设备忙（请先卸载已挂载的分区）` | 分区已挂载或被占用 | 关闭文件管理器窗口；`sudo umount /dev/sdb1` |
| `目标设备正被上述进程占用` | 文件管理器/同步工具/dd 持有设备 | 按提示关闭进程；`rufus ps` 复查；确认无碍可加 `--no-conflict-check` |
| `设备太小` / `空间不足` | 镜像大于 U 盘 | 换更大的 U 盘 |
| `mkfs.vfat 失败` | 未安装 dosfstools | `sudo apt install dosfstools` |
| `syslinux 安装失败` | 未安装 syslinux | `sudo apt install syslinux syslinux-common`（不影响 UEFI 启动） |
| `该镜像需要 UEFI:NTFS 才能…但找不到 uefi-ntfs.img` | 数据文件未安装 | 重装本包，或用 `--uefi-ntfs=<路径>` / 环境变量 `RUFUS_UEFI_NTFS_IMG`；也可改用 `--fs fat32` |
| Windows 安装报 "install.wim 太大" | FAT32 单文件 4 GiB 限制 | 改用 `--fs ntfs` |
| `未找到 ISO 目录文件` | 目录文件缺失 | `rufus download --update-catalog <URL>`，或用 `--catalog <文件>` |
| 下载报 `SHA256 校验失败` | 下载损坏或镜像已更新 | 删除已下载文件后重试；若发行版刚发新版本，更新目录 |
| ISO 解包后 U 盘 BIOS 无法启动 | 缺 BIOS 引导代码 | `rufus mbr -t syslinux /dev/sdb` 补写 |
| 进度长时间不动 | U 盘写入慢或出现坏块 | 耐心等待；必要时中止并做 `badblocks` 检测 |

---

## 移植了什么（代码复用）

上游 Rufus 把大量平台无关代码内嵌在源码树中。本项目**原样复用**了其中两块：

| 上游来源 | 复用内容 | 规模 |
| --- | --- | --- |
| `src/libcdio/` | ISO9660 / UDF / Rock Ridge / Joliet 解析、通用 stdio 流驱动 | 21 个 .c / 59 个文件 / 17 635 行 |
| `src/ms-sys/` | MBR 与 FAT12/16/32/NTFS 分区引导记录数据与写入逻辑 | 6 个 .c / 56 个文件 / 3 364 行 |
| `res/uefi/uefi-ntfs.img` | UEFI:NTFS 驱动镜像（1 MiB FAT12，各架构 EFI 驱动） | 1 MiB |

对这两块的改动**仅限于**：

- 重写 `libcdio/config.h` 为 Linux 版（上游那份是 MinGW/MSVC 专用）；
- 新增 `cdio_shim.c` 打 2 个符号（上游自己在 `iso.c` 里也是这么做的）；
- 为 ms-sys 补一个基于 stdio 的 `file.c`（其余源文件零改动）。

复用之后，Rufus 最"硬核"的部分——ISO 解析与引导记录写入——
**字节级等同于 Windows 版**，而不是重新发明。

重写的是平台层（约 11 000 行自有代码）：

```
CreateFile("\\\\.\\PhysicalDriveN")  →  open("/dev/sdX")
SetupAPI 设备枚举                     →  /sys/block + /proc/self/mountinfo
IOCTL_DISK_SET_DRIVE_LAYOUT_EX        →  直接构造 MBR/GPT 扇区（rf_part.c）
fmifs.dll!FormatEx                    →  mkfs.vfat / exfat / ntfs / ext4 / udffs
SetFilePointerEx + WriteFile          →  pread / pwrite + fsync + BLKFLSBUF
NtQuerySystemInformation(句柄表)      →  /proc/<pid>/fd 扫描（rf_process.c）
WinHTTP                               →  libcurl（rf_http.c）
Win32 对话框                          →  GTK3
SetTimer 状态刷新                     →  进度回调 + GTK 定时器
UAC / 提权                            →  polkit（pkexec + policy 文件）
```

---

## 项目结构

```
rufus-linux/
├── Makefile                        纯 Makefile 构建系统
├── README.md                       本文件
├── ChangeLog                       变更记录
├── LICENSE.txt                     GPL-3.0（上游原样）
├── data/                           运行期资源
│   ├── rufus-linux.desktop         桌面菜单项
│   ├── rufus-linux.png             应用图标（本项目自绘）
│   ├── rufus.1 / rufus-gtk.1       手册页
│   ├── io.github.rufus-linux.policy.in   polkit 策略模板
│   ├── iso-catalog.json            ISO 下载目录（53 条）
│   └── uefi/uefi-ntfs.img          UEFI:NTFS 驱动镜像
├── debian/                         Debian 打包
│   ├── control  rules  changelog  copyright
│   ├── source/format               3.0 (native)
│   └── README.source
├── docs/                           技术文档（中文，7 份）
├── include/                        公共头文件（10 个）
│   ├── rufus_linux.h               版本 / 错误码 / 进度 / 日志 / 工具
│   ├── rf_device.h  rf_image.h  rf_write.h  rf_hash.h
│   ├── rf_badblocks.h  rf_mbr.h  rf_part.h  rf_format.h
│   ├── rf_process.h  rf_http.h  rf_catalog.h  rf_json.h
│   ├── rf_privilege.h  rf_uefi_ntfs.h  rf_usb.h
└── src/
    ├── core/                       Linux 平台层与核心逻辑（10 个 .c）
    ├── cli/main.c                  命令行程序
    ├── gui/main.c                  GTK3 图形界面
    └── third_party/                从上游移植
        ├── libcdio/                ISO9660 / UDF / 驱动 + Linux 版 config.h
        └── mssys/                  ms-sys 引导记录写入
```

---

## 与 Windows 版的差异

已补齐的上游能力（1.1.0 / 1.2.0）：

- **冲突进程检测** —— 等价于上游 `process.c` 的句柄占用检测
- **在线下载 ISO** —— 上游依赖 PowerShell 脚本 Fido，本移植改为内置 JSON 目录 + libcurl
- **UEFI:NTFS** —— 复用上游 `res/uefi/uefi-ntfs.img`，分区属性逐条对齐
- **免 sudo 授权** —— 上游用 UAC 清单，本移植用 polkit

仍未移植：

| 功能 | 上游实现 | 本移植 |
| --- | --- | --- |
| 数字签名校验 | WinTrust | 改为官方 SHA256 校验和比对 |
| Windows To Go | `wue.c` + BCD 编辑 | 未实现（仅识别 Windows 安装盘） |
| 无人值守应答文件 | `parser.c` | 未实现 |
| 配置持久化 | 注册表 | 无状态，改用命令行参数 |
| 光盘 / VHD / FFU 创建 | `vhd.c` | 未实现 |
| 38 种界面语言 | `.loc` 嵌入式语言包 | 仅中文 + 英文 |

完整差异清单与原因见 `docs/02-Linux移植设计与实现.md` §2.8。

---

## 技术文档

`docs/` 下有 7 份中文技术文档，随包安装到 `/usr/share/doc/rufus-linux/`：

| 文档 | 内容 |
| --- | --- |
| [01-Rufus源码架构分析](docs/01-Rufus源码架构分析.md) | 上游 13.9 万行的模块划分、核心流程、Win32 依赖盘点 |
| [02-Linux移植设计与实现](docs/02-Linux移植设计与实现.md) | 移植策略、模块映射表、关键实现细节、技术问题与解决 |
| [03-构建与打包指南](docs/03-构建与打包指南.md) | 依赖、构建变量、deb 打包、交叉编译、调试方法 |
| [04-用户手册](docs/04-用户手册.md) | 全部命令与选项、典型场景、自动决策规则、故障排查 |
| [05-测试与验证报告](docs/05-测试与验证报告.md) | 19 项实机测试与原始输出 |
| [06-扩展功能实现](docs/06-扩展功能实现.md) | 冲突进程检测 / 在线下载 / UEFI:NTFS 的移植细节 |
| [07-polkit授权机制](docs/07-polkit授权机制.md) | 免 sudo 启动、授权对话框、两阶段状态文件协议、只读降级 |

---

## 致谢与许可证

本项目是 [Rufus](https://github.com/pbatard/rufus) 的 Linux 移植，
上游由 Pete Batard 及全体贡献者开发。同时感谢：

- [libcdio](https://www.gnu.org/software/libcdio/) — Rocky Bernstein 等
- [ms-sys](http://ms-sys.sourceforge.net/) — Henrik Carlqvist
- [e2fsprogs](https://e2fsprogs.sourceforge.net/) — Theodore Ts'o 等（坏块检测算法来源）
- [wimlib](https://wimlib.net/) — Eric Biggers
- [pbatard/uefi-ntfs](https://github.com/pbatard/uefi-ntfs) — UEFI:NTFS 驱动

**许可证：GPL-3.0-or-later**，与上游 Rufus 一致。
详见 `LICENSE.txt` 与 `debian/copyright`（其中逐目录标注了各第三方模块的来源与许可）。

> 本项目**未使用**上游的图标资源 —— 上游状态图标来自 Axialis 图标集
> （CC BY-ND 4.0 / 商业许可，不在 GPL 覆盖范围内）。`data/rufus-linux.png`
> 是本项目自行绘制的。
